var express = require('express');
var router = express.Router();
var mysql = require('mysql');
const util = require('util');
var tokenAuth = require('../lib/tokenAuth')

var con = mysql.createConnection({
  host: "mysql",
  user: "root",
  password: "secret",
  database: "neighbors",
  multipleStatements: true
});
con.connect()

// node native promisify
const query = util.promisify(con.query).bind(con);

router.post('/', async function (req, res, next) {
    try {
        const username = req.body.username,
            password = req.body.password;

        if (await validateNameAndPassword(username, password)) {
            const userId = await findUserIdForName(username);
            let token = tokenAuth.sign(userId)
            let decodedToken = tokenAuth.decode(token)
            // send the JWT back to the user
            // TODO - multiple options available
            res.status(200).json({idToken: token, userId: userId, expiresIn: decodedToken.payload.exp})
        } else {
            // send status 401 Unauthorized
            res.sendStatus(401);
        }
    } catch (error) {
        console.error(error)
        res.sendStatus(401);
    }
});

async function validateNameAndPassword(username, password) {
    try {
        let response = await query(`call uspLogin(?, ?, @output); select @output;`, [username, password]);
        if (response[1][0]['@output'] == 'User successfully logged in') {
            return true
        } else {
            console.log(response[1][0]['@output'])
            return false
        }
    } catch (error) {
        console.error(error)
        return false
    }
}

async function findUserIdForName(username) {
    try {
        let response = await query(`select bin_to_uuid(userId) as userId from Users where loginName = ?`, username)
        if (response.length == 1) {
            return response[0].userId;
        } else {
            throw 'Could not get user';
        }
    } catch (error) {
        console.error(error)
        throw error
    }
}

module.exports = router;