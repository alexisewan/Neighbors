import { Injectable } from '@angular/core';
import { IPost } from '../interfaces/post';
import { Observable, of } from 'rxjs'
import { catchError, map, tap } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { IReport } from '../interfaces/report';

@Injectable({
  providedIn: 'root'
})
export class PostService {
  private postsUrl = '/posts';
  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

  constructor(
    private http: HttpClient,
  ) { }

  /**
   * gets all of the posts.
   * @returns array of posts from the API
   */
  getAll(): Observable<IPost[]> {
    return this.http.get<IPost[]>(this.postsUrl).pipe(
      tap(_ => console.log('fetched posts')),
      catchError(this.handleError<IPost[]>('getPosts', []))
    );
  }

  /** GET post by id. Will 404 if id not found
   * @param id - a guid specifying the Id of the post.
  */
  getById(id: string): Observable<IPost> {
    const url = `${this.postsUrl}/${id}`;
    return this.http.get<IPost>(url).pipe(
      tap(_ => console.log(`fetched post id=${id}`)),
      catchError(this.handleError<IPost>(`getPost id=${id}`))
    );
  }

  /** GET post by id. Will 404 if id not found
  * @param id - a guid specifying the Id of the post.
  */
  getMine(): Observable<IPost[]> {
    const url = `${this.postsUrl}/mine`;
    return this.http.get<IPost[]>(url).pipe(
      tap(_ => console.log(`fetched my posts`)),
      catchError(this.handleError<IPost[]>(`getMine`))
    );
  }

  /** POST: add a new post to the server */
  add(post: IPost): Observable<IPost> {
    return this.http.post<IPost>(this.postsUrl, post, this.httpOptions).pipe(
      tap((newPost: IPost) => console.log(`added post w/ id=${newPost.postId}`)),
      catchError(this.handleError<IPost>('addPost'))
    );
  }

  /** DELETE: delete the post from the server */
  delete(id: string): Observable<IPost> {
    const url = `${this.postsUrl}/${id}`;
    return this.http.delete<IPost>(url, this.httpOptions).pipe(
      tap(_ => console.log(`deleted hero id=${id}`)),
      catchError(this.handleError<IPost>('deletePost'))
    );
  }

  /** PUT: report the post */
  /*TODO: connect this to the report.service so the post is updated when a report is made */
  report(id: string, type: string, description: string): Observable<IReport> {
    const url = `${this.postsUrl}/${id}/report`;
    return this.http.put<IReport>(url, { reportType: type, reportDescription: description, postId: id, }, this.httpOptions).pipe(
      tap(_ => console.log(`reported post =${id}`)),
      catchError(this.handleError<IReport>('reportPost'))
    );
  }

  /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      throw error
    };
  }
}
