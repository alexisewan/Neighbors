import { Component } from '@angular/core';
import { IPost } from '../interfaces/post';
import { IUser } from '../interfaces/user';
import { PostService } from '../services/post.service';
import { UserService } from '../services/user.service';
import { DataService } from '../services/data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html'
})
export class ProfileComponent {
  title = 'neighbors-app';
  filter = '';
  posts: IPost[] = [];
  user: IUser = {userId: "", username: "", firstName: "", lastName: "", profilePicture: new Blob, karma: -1, userLocation: "", userLanguage: ""};

  constructor(private postService: PostService, private userService: UserService, private sharingService: DataService, private router: Router) {}

  ngOnInit() {
    // this.getSelf()
    this.getUser()
    this.getPosts()
  }

  getUser() {
    if(this.sharingService.getType() == "string") {
      this.getSelf();
    }
    else {
      this.user = this.sharingService.getData();
      console.log("Got the user");
      console.log(this.user);
    }
  }

  getSelf() {
    this.userService.getSelf().subscribe((user) => {
      console.log("Got my Info");
      console.log(user);
      this.user = user;
    });
  }

  getPosts() {
    this.postService.getMine()
    .subscribe((posts) => {
      console.log("got my posts!")
      // console.log(posts)
      this.posts = posts;
      console.log(this.posts);
    });
  }

  SetFilter(clickedFilter: string) {
    if(this.filter == clickedFilter)
      this.filter = '';
    else
      this.filter= clickedFilter;
  }

  viewProfile(user: IUser) {
    this.sharingService.setData(user);
    this.router.navigate(['/profile']);
  }

  reportUser(user: IUser) {
    this.sharingService.setData(user.userId);
    this.router.navigate(['/report']);
  }

  reportPost(post: IPost) {
    this.sharingService.setData(post.user?.userId);
    this.router.navigate(['/report']);
  }

  startChat(user: IUser) {
    this.sharingService.setData(user.userId);
    this.router.navigate(['/chat']);
  }
}
