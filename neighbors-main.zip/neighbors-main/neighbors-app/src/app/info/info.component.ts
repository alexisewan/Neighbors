import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './info.component.html'
})
export class InfoComponent {
  title = 'neighbors-app';
}
