import { CurrencyPipe } from '@angular/common';
import { Component } from '@angular/core';
import { connectableObservableDescriptor } from 'rxjs/internal/observable/ConnectableObservable';
import { IMessage } from '../interfaces/message';
import { IUser } from '../interfaces/user';
import { ChatService } from '../services/chat.service';
import { UserService } from '../services/user.service';
import { Router } from '@angular/router';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-root',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.css']
})
export class ChatComponent {
  title = 'neighbors-app';
  messages: IMessage[] = [];
  users: IUser[] = []; 
  userIds: { userId: string}[] = [];
  messageTimes: {[userId: string]: Date} = {}
  selectedUser: IUser = {userId: "temp", username: "temp", firstName: "temp", lastName: "temp", profilePicture: new Blob, karma: 0, userLocation: "temp", userLanguage: "temp"};
  outgoingMsg = "";
  selectionMade = false;
  numUsers = 0;
  thisUser: string

  constructor(
    private chatService: ChatService,
    private userService: UserService,
    private sharingService: DataService,
    private router: Router
    ) {
      this.thisUser = localStorage.getItem("user_id") ?? "unknownUser";
    }

  ngOnInit() {
    this.getUserIds()
    //this.getMessages()
    setInterval(this.pollMessages.bind(this), 1000);
  }

  getUserIds() {
    this.chatService.getConversations().subscribe((userIds) => {
      console.log("user ids");
      console.log(userIds);
      this.userIds = userIds;
      // this complex pile of logic is first mapping the userId array into an array of userId and lastMsg time.
      // Then it converts the array into a dictionary that keys the lastMsg Date by userId value.
      // there should be a more elegant way to do this using reduce, but I couldnt get it working.
      this.messageTimes = Object.assign({}, ...(userIds.map((currentId) => {
        return { userId: currentId.userId, lastMsg: new Date(0)};
      })).map((x) => ({[x.userId]: x.lastMsg})));
      this.getUsers()
    });
  }

  getUsers() {
    this.numUsers = this.userIds.length;
    for (var i = 0; i < this.userIds.length; i++) {
      this.userService.getUser(this.userIds[i].userId).subscribe((user) => {
        // skip the current user.
        if (user.userId != this.thisUser) {
          this.users.push(user);
        }
      });
    }
  }

  getMessages() {
    let currTime = new Date()
    for (let i = 0; i < this.users.length; i++) {
      // get the last time this user had their messages polled, and update it when we get the new messages.
      let timeCall = this.messageTimes[this.users[i].userId].toISOString().slice(0, 19);
      this.chatService.getConversation(this.users[i].userId, timeCall).subscribe((messages) => {
        // only update timeSince if there were messages. to avoid skipping messages
        if(messages.length > 0) {
          this.messageTimes[this.users[i].userId] = currTime
        }
        this.messages = this.messages.concat(messages)
        document.getElementById(`${this.messages.length - 1}`)?.scrollIntoView()
      });
    }
  }

  pollMessages = () => {
    if (this.selectedUser.userId != "temp") {
      let currTime = new Date()
      // get the last time this user had their messages polled, and update it when we get the new messages.
      let timeCall = this.messageTimes[this.selectedUser.userId].toISOString().slice(0, 19);
      this.chatService.getConversation(this.selectedUser.userId, timeCall).subscribe((messages) => {
        // only update timeSince if there were messages. to avoid skipping messages
        if(messages.length > 0) {
          this.messageTimes[this.selectedUser.userId] = currTime
        }
        this.messages = this.messages.concat(messages)
        if (messages.length > 0) {
          document.getElementById(`${this.messages.length - 1}`)?.scrollIntoView()
        }
      });
    }
  }

  onSelect(user: IUser) {
    // reset message times for the previous user, so we can re-pull all their conversations if they are selected again
    this.selectedUser = user;
    this.messageTimes[user.userId] = new Date(0)
    this.selectionMade = true;
    this.messages = [];
  }

  onSend() {
    if(this.outgoingMsg != "")
    {
      var time = new Date().toISOString().slice(0, 19);
      // getMessages will pull this message from the DB.
      //this.messages.push({msgId: '', content: this.outgoingMsg, timestamp: time, read: false, sender: this.thisUser, recipient: this.selectedUser.userId});
      this.chatService.sendMessage(this.selectedUser.userId, this.outgoingMsg).subscribe(() => {console.log("message sent!")});
      this.outgoingMsg = "";
    }
  }

  viewProfile(user: IUser) {
    this.sharingService.setData(user);
    this.router.navigate(['/profile']);
  }

  reportUser(user: IUser) {
    this.sharingService.setData(user.userId);
    this.router.navigate(['/report']);
  }
}
