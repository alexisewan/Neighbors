import { Injectable } from '@angular/core';
import { Observable } from 'rxjs'
import { catchError, tap } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { IUser } from '../interfaces/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  // user API is exposed at /users endpoints.
  private usersUrl = '/users';
  httpOptions = {
    // we are recieving json data.
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

  // include the Angular httpClient, which actually makes the HTTP requests for us.
  constructor(
    private http: HttpClient,
    ) { };

  // Get the currently logged in user's data.
  // This leverages the userId being passed as part of the authentication system, and automatically added to all requests by the authInterceptor.
  getSelf(): Observable<IUser> {
    // configure the URL for this endpoint.
    let url = this.usersUrl + '/self'
    // make the GET call, then pipe it to a tap which does debugging logging, then error handling to catch any errors returned.
    // if no errors are returned, the Observable returned can be subscribed to and will output an IUser object populated with the information returned from the /users/self backend API.
    return this.http.get<IUser>(url).pipe(
      tap(_ => console.log('fetched this user')),
      catchError(this.handleError<IUser>('getSelf', undefined))
    );
  };

  // get all user's data.
  getAll(): Observable<IUser[]> {
    // this API is specified in the backend as a GET to /users endpoint.
    // make the GET call, then pipe it to a tap which does debugging logging, then error handling to catch any errors returned.
    // if no errors are returned, the Observable returned can be subscribed to and will output an array of IUser objects, one for each user defined in the database. (this is the info returned by the /users API)
    return this.http.get<IUser[]>(this.usersUrl).pipe(
      tap(_ => console.log('fetched all users')),
      catchError(this.handleError<IUser[]>('getAll', []))
    );
  };

  // get a specific user's data.
  getUser(userId: string): Observable<IUser> {
    // configure the URL for this endpoint, it takes a path parameter of the userId you want the IUser object for.
    let url = this.usersUrl + `/${userId}`
    // make the GET call, then pipe it to a tap which does debugging logging, then error handling to catch any errors returned.
    // if no errors are returned, the Observable returned can be subscribed to and will output an IUser object populated with the information returned from the /users/:userId backend API.
    return this.http.get<IUser>(url).pipe(
      tap(_ => console.log('fetched all users')),
      catchError(this.handleError<IUser>('getUser', undefined))
    );
  };

  /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      throw error
    };
  };
}
