var express = require('express');
var router = express.Router();
var mysql = require('mysql');
const util = require('util');
const { v4: uuidv4 } = require('uuid');
const jwtMiddleware = require('../lib/jwt-middleware');

var con = mysql.createConnection({
  host: "mysql",
  user: "root",
  password: "secret",
  database: "neighbors"
});
con.connect()

// node native promisify
const query = util.promisify(con.query).bind(con);

router.use(jwtMiddleware);

/* GET services listing. */
router.get('/', async function(req, res, next) {
  console.log('getting services');
  try {
    let serviceResult = await query('Select BIN_TO_UUID(serviceID) as serviceId, serviceTitle as title, serviceDesc as description, link, nextSteps, photo, resourceName as category, bin_to_uuid(userId) as userId, locationId from Services s join ResourceCategories r on r.categoryId = s.categoryId')
    console.log('got services');
    // populate location information for the services
    // TODO: make this part of a join in the first query
    for(let service of serviceResult) {
      if (service.locationId) {
        service.location = await query('select streetAddress, city, country, zipCode from `Locations` where locationId = ?', service.locationId)
        if(service.location.length == 0) {
          throw `No location found for post: ${service.serviceId}`;
        }
        service.location = service.location[0]
        delete service.locationId
      }
      // TODO: remove once we have fiugred out where we are doing location generalizing
      service.location = "5 miles";
    }
    res.send(serviceResult);
  } catch (error) {
    console.error(error)
    next( error)
  }
});

/* GET service */
router.get('/:serviceId', async function(req, res, next) {
  try {
  let serviceResult = await getService(req.params.serviceId)
  res.send(serviceResult);
  } catch (error) {
    console.error(error)
    next( error);
  }
});

/* POST service. */
router.post('/', async function(req, res, next) {
  try {
    console.log('inserting a service');
    // insert the location if it does not exist already.
    let locationResults = await query('select locationId from `Locations` where streetAddress = ? and city = ? and country = ? and zipCode = ?', [req.body.location.streetAddress, req.body.location.city, req.body.location.country, req.body.location.zipCode]);
    console.log(locationResults)
    if (locationResults.length == 0) {
      // we need to insert the location.
      locationResults = await query('INSERT INTO Locations SET ?', req.body.location);
      console.log(locationResults.insertId);
      req.body.locationId = locationResults.insertId;
    } else {
      console.log(locationResults[0])
      req.body.locationId = locationResults[0].locationId
    }
    delete req.body.location;
    // get the cateogry Id
    let categoryResults = await query('select categoryId from ResourceCategories where resourceName = ?', req.body.categoryName);
    console.log(categoryResults)
    if(categoryResults.length == 0) {
      throw `Error: could not find category named: ${req.body.categoryName}`;
    } else {
      let categoryId = categoryResults[0].categoryId
      let serviceUuid = uuidv4()
      let result = await query('insert into `Services` (serviceId, serviceTitle, serviceDesc, link, nextSteps, photo, categoryId, userId, locationId) values (uuid_to_bin(?), ?, ?, ?, ?, ?, ?, uuid_to_bin(?), ?)', [serviceUuid, req.body.title, req.body.description, req.body.link, req.body.nextSteps, req.body.photo, categoryId, req.userId, req.body.locationId])
      console.log('inserted a service');
      let serviceResult = await getService(serviceUuid)
      res.send(serviceResult);
    }
  } catch (error) {
    console.error(error)
    next( error);
  }
});

/* UPDATE service. */
router.put('/:serviceId', async function(req, res, next) {
  try {
    console.log('updating service');
    // parse through request and see what changed.
    let sqlUpdate = '';
    if(req.body.title) {
      sqlUpdate += `serviceTitle = '${connection.escape(req.body.title)}'`
    }
    if (req.body.description) {
      sqlUpdate += `serviceDesc = '${connection.escape(req.body.description)}'`
    }
    if (req.body.photo) {
      sqlUpdate += `photo = '${connection.escape(req.body.photo)}'`
    }
    if (req.body.link) {
      sqlUpdate += `link = '${connection.escape(req.body.link)}'`
    }
    if (req.body.nextSteps) {
      sqlUpdate += `nextSteps = '${connection.escape(req.body.nextSteps)}'`
    }
    if (sqlUpdate == '') {
      res.send('Nothing to update')
    } else {
      sqlUpdate = 'update `Services` SET ' + sqlUpdate + ` where serviceId = uuid_to_bin(${connection.escape(req.params.serviceId)})`
      let updateResults = await query(sqlUpdate)
      console.log('updated a service');
      let service = await getService(req.params.serviceId)
      res.send(service);
    }
  } catch (error) {
    console.error(error)
    next(error);
  }
});

/* report a service */
router.put('/:serviceId/report', async function(req, res, next) {
  try {
    console.log('reporting service: ', req.params.serviceId);
    let reportUuid = uuidv4();
    let reportResults = await query('insert into `Reports` (reportId, reportType, reportDesc, serviceId, reporterUserId) values (uuid_to_bin(?), ?, ?, uuid_to_bin(?), uuid_to_bin(?))', [reportUuid, req.body.reportType, req.body.reportDescription, req.params.serviceId, req.userId]);
    let report = await query('select bin_to_uuid(reportId) reportId, reportType, reportDesc as reportDescription, bin_to_uuid(reporterUserId) as reporterUserId, bin_to_uuid(serviceId) as serviceId from Reports where reportId = uuid_to_bin(?)', reportUuid);
    res.send(report[0]);
  } catch(error) {
    console.error(error)
    next(error);
  }
});

/* DELETE service. */
router.delete('/:serviceId', async function(req, res, next) {
  try {
    console.log('deleting service');
    let results = await query('delete from `Services` where serviceId = uuid_to_bin(?)', req.params.serviceId);
    console.log('deleted a service');
    // deleting something that doesnt exist, and deleting the specified service are both success.
    if (results.affectedRows < 2) {
      res.send('success');
    } else {
      throw `error deleting ${serviceId}`
    }
  } catch (error) {
    console.error(error)
    next(error)
  }
});

// Helper / internal functions

async function getService(serviceId) {
  let serviceResult = await query('Select BIN_TO_UUID(serviceID) as serviceId, serviceTitle as title, serviceDesc as description, link, nextSteps, photo, resourceName as category, bin_to_uuid(userId) as userId, locationId from `Services` s join `ResourceCategories` r on r.categoryId = s.categoryId where s.serviceId = uuid_to_bin(?)', serviceId)
  console.log('got service');
  if (serviceResult.length == 0) {
    throw `No service matching: ${serviceId}`
  }
  serviceResult = serviceResult[0]
  // populate location information for the services
  if (serviceResult.locationId) {
    serviceResult.location = await query('select streetAddress, city, country, zipCode from `Locations` where locationId = ?', serviceResult.locationId)
    if(serviceResult.location.length == 0) {
      throw `No location found for service: ${serviceId}`;
    }
    serviceResult.location = serviceResult.location[0]
    delete serviceResult.locationId
  }
  // TODO: remove once we have fiugred out where we are doing location generalizing
  serviceResult.location = "5 miles";
  return serviceResult;
}

module.exports = router;
