import { Injectable } from '@angular/core';
import { IReport } from '../interfaces/report';
import { Observable, of } from 'rxjs'
import { catchError, map, tap } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ReportService {
  private reportUrl = '/reports';
  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

  constructor(
    private http: HttpClient,
    ) { }

  /**
   * gets all of the reports.
   * @returns array of reports from the API
   */
  getAll(): Observable<IReport[]> {
    return this.http.get<IReport[]>(this.reportUrl).pipe(
        tap(_ => console.log('fetched reports')),
        catchError(this.handleError<IReport[]>('getReports', []))
      );
  }

  /** GET report by id. Will 404 if id not found
   * @param id - a guid specifying the Id of the report.
  */
  getById(id: string): Observable<IReport> {
    const url = `${this.reportUrl}/${id}`;
    return this.http.get<IReport>(url).pipe(
      tap(_ => console.log(`fetched report id=${id}`)),
      catchError(this.handleError<IReport>(`getReport id=${id}`))
    );
  }

  /** REPORT: add a new report to the server */
  add(report: IReport): Observable<IReport> {
    return this.http.post<IReport>(this.reportUrl, report, this.httpOptions).pipe(
      tap((newReport: IReport) => console.log(`added report w/ id=${newReport.reportId}`)),
      catchError(this.handleError<IReport>('addReport'))
    );
  }

  /** DELETE: delete the report from the server */
  delete(id: string): Observable<IReport> {
    const url = `${this.reportUrl}/${id}`;
    return this.http.delete<IReport>(url, this.httpOptions).pipe(
      tap(_ => console.log(`deleted hero id=${id}`)),
      catchError(this.handleError<IReport>('deleteReport'))
    );
  }

  /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      throw error
    };
  }
}