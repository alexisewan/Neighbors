// TODO: Add function to pull from the database and add the infromation to the list of reports when the page loads

import { Component } from '@angular/core';
import { IReport } from '../interfaces/report';
import { ReportService } from '../services/report.service';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-root',
  templateUrl: './reportuser.component.html'
})
export class ReportComponent {
  title = 'neighbors-app';
  formType = 'Report';
  report: IReport = {reportId: '', reportType: '', reportDescription: '', reporterUserId: '', postId: '', serviceId: '', reportedUserId: ''};

  constructor(
    private reportService: ReportService,
    private sharingService: DataService
  ) {}

  ngOnInit() {
    this.getReportedId()
  }

  getReportedId() {
    this.report.reportedUserId = this.sharingService.getData();
  }

  onSubmit(): void {
    if(confirm('Are you sure you want to report this user?')) {
      console.log('Report has been submitted');
      console.log(this.report);
      this.AddReport();
      this.report = {reportId: '', reportType: '', reportDescription: '', reporterUserId: '', postId: '', serviceId: '', reportedUserId: ''};
    }
  }

  AddReport() {
    let serviceToUse: ReportService
    serviceToUse = this.reportService;
    serviceToUse.add(this.report).subscribe((report) => {console.log (report)}, (error) => {console.error(error)});
  };
}