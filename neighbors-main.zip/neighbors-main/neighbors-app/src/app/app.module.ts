import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'; 

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { InfoComponent } from './info/info.component';
import { FormComponent } from './createPost/form.component';
import { NeedHelpComponent } from './forumPages/needHelp.component';
import { CanHelpComponent } from './forumPages/canHelp.component';
import { ServicesComponent } from './forumPages/services.component';
import { ChatComponent } from './chat/chat.component';
import { ReportComponent } from './report/reportuser.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { LoginComponent } from './login/login.component';
import { AuthInterceptor } from './services/authInterceptor';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    NeedHelpComponent, 
    CanHelpComponent,
    ServicesComponent,
    InfoComponent,
    FormComponent, 
    ReportComponent,
    ChatComponent,
    LoginComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
  ],
  providers: [{ provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true }],
  bootstrap: [AppComponent]
})
export class AppModule { }
