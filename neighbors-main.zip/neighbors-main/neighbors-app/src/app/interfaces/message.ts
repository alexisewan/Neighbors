export interface IMessage {
    msgId: string,
    content: string,
    timestamp: string,
    read: boolean,
    sender: string,
    recipient: string
}