import { Injectable } from '@angular/core';
import { IPost } from '../interfaces/post';
import { Observable, of } from 'rxjs'
import { catchError, map, tap } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { IReport } from '../interfaces/report';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  private servicesUrl = '/services';
  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

  constructor(
    private http: HttpClient,
    ) { }

  /**
   * gets all of the services.
   * @returns array of services from the API
   */
  getAll(): Observable<IPost[]> {
    return this.http.get<IPost[]>(this.servicesUrl).pipe(
        tap(_ => console.log('fetched services')),
        catchError(this.handleError<IPost[]>('getServices', []))
      );
  }

  /** GET service by id. Will 404 if id not found
   * @param id - a guid specifying the Id of the service.
  */
  getById(id: string): Observable<IPost> {
    const url = `${this.servicesUrl}/${id}`;
    return this.http.get<IPost>(url).pipe(
      tap(_ => console.log(`fetched service id=${id}`)),
      catchError(this.handleError<IPost>(`getService id=${id}`))
    );
  }

  /** POST: add a new service to the server */
  // TODO: Translate from IPost object into what the service API expects (it is almost the same, with small differences).
  add(service: IPost): Observable<IPost> {
    return this.http.post<IPost>(this.servicesUrl, service, this.httpOptions).pipe(
      tap((newService: IPost) => console.log(`added post w/ id=${newService.postId}`)),
      catchError(this.handleError<IPost>('addService'))
    );
  }

  /** DELETE: delete the service from the server */
  delete(id: string): Observable<IPost> {
    const url = `${this.servicesUrl}/${id}`;
    return this.http.delete<IPost>(url, this.httpOptions).pipe(
      tap(_ => console.log(`deleted service id=${id}`)),
      catchError(this.handleError<IPost>('deleteService'))
    );
  }

  /** PUT: report the service */
  /*TODO: connect this to the report.service so the service is updated when a report is made */
  report(id: string, type: string, description: string): Observable<IReport> {
    const url = `${this.servicesUrl}/${id}/report`;
    return this.http.put<IReport>(url, {reportType: type, reportDescription: description, serviceId: id, }, this.httpOptions).pipe(
      tap(_ => console.log(`reported post =${id}`)),
      catchError(this.handleError<IReport>('reportService'))
    );
  }

  /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      throw error
    };
  }
}
