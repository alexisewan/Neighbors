var express = require('express');
var router = express.Router();
var mysql = require('mysql');
const util = require('util');
const { v4: uuidv4 } = require('uuid');
const { report } = require('./users');

var con = mysql.createConnection({
  host: "mysql",
  user: "root",
  password: "secret",
  database: "neighbors"
});
con.connect()

// node native promisify
const query = util.promisify(con.query).bind(con);

/* ADD report. */
router.post('/', async function(req, res, next) {
  let userResults;
    try {
      console.log('inserting a report');
      // checking that the reporter user exists
      if (req.body.reporterUserId) {
        // find the cooresponding userId to ensure it exists
        userResults = await query('select userId from `Users` where userId = ?', [req.body.reporterUserId]);
        console.log(userResults)
      } 
      if(userResults == undefined || userResults.length == 0){
        throw `Reporter user could not be found with userId  ${req.body.reporterUserId}`;
      }

      //checking that the field being reported exists
      let verifyResults = null;
      //if they are reporting a user
      if (req.body.reportedUserId != undefined) {
        // find the cooresponding userId to ensure it exists
        verifyResults = await query('select userId from `Users` where userId = ?', [req.body.reportedUserId]);
        console.log(verifyResults)
      } 
      //if they are reporting a post
      else if (req.body.postId != undefined){
        // find the cooresponding postId to ensure it exists
        verifyResults = await query('select postId from `Posts` where postId = ?', [req.body.postId]);
        console.log(verifyResults)
      }
      //if they are reporting a service
      else if (req.body.serviceId != undefined){
        // find the cooresponding serviceId to ensure it exists
        verifyResults = await query('select serviceId from `Services` where serviceId = ?', [req.body.serviceId]);
        console.log(verifyResults)
      }
      //if all 3 are undefined
      else {
        throw `No item is being reported.`;
      }

      if(verifyResults.length == 0){
        throw `Item being reported could not be found.`;
      }
        let reportUuid = uuidv4();
        reportResult = await query ('insert into `Reports` (reportId, reportType, reportDescription, reporterUserId, reportId, serviceId, reportedUserId) values (uuid_to_bin(?), ?, ?, ?, ?, ?, ?)', [reportUuid, req.body.reportType, req.body.reportDescription, req.body.reporterUserId, req.body.postId, req.body.serviceId, req.body.reportedUserId]);
        if(reportResult > 0){
            console.log('inserted a report');
        } else{
            throw `Report could not be inserted.`;
        }
        let report = await getReport(reportUuid);
        res.send(report);

    } catch (error) {
      console.error(error)
      next(error)
    }
  });

  // Helper / internal functions
async function getReport(reportId) {
    let reportResult = await query('Select BIN_TO_UUID(reportId) as reportId, reportType, reportDescription, reporterUserId, postId, serviceId, reportedUserId', reportId)
    console.log('got report');
    if (reportResult.length == 0) {
      throw `No report matching: ${reportId}`
    } else {
      reportResult = reportResult[0]
      return reportResult;
    }
  }

module.exports = router;