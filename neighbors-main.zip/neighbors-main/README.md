# Neighbors
This app currently consists of a Node backend (Node 14), with an Angular frontend (Angular 12).
The database is provided by a mySql DB running in another docker container (MySQL 8)

docker is used to build the initial container image. After that, local development is accomplished by modifying files in this directory, and they are mounted into the container.
This means we don't need to rebuild the container every time, just restart it to take in the new node changes.
For frontend updates, if we re-build the frontend, it will instantly update the UI being served by the container.

Database chagnes are not persisted between container restarts.
There is a minimal data setup script in the sql-startup-scripts folder. This will be used to configure the database, and populate it with any quality of life testing information.

There is a lot more work that needs to be done for quality of life. This includes helper scripts, a more thurough readme, and a better buildout of the sql database.

## Getting Started
1. We will need to install [Docker for Desktop](https://www.docker.com/products/docker-desktop)
2. We will need to install [Node](https://nodejs.org/en/download/)

## Downloaded to Running
1. build the container. `docker build -t mynodeapp .` from this directory
2. docker-compose up
3. go to `localhost:5000` to see the app UI.
4. you can call `localhost:5000\users`, `localhost:5000\posts` in the browser to see the API backend calls working.
5. you can also use Postman or something else to POST or DELETE `localhost:5000\posts` with the required json data
   1. POST requires something like `{"title": "test", "description": "some description", "duration": "2021-11-01 17:00:00"}` as the JSON body
   2. DELETE requires calling `localhost:5000\posts\:UUID` where :UUID is the string ID of a post you have created.

## Building the container
In order to use the docker container for development, we will need to build it at least once.
WWU doesn't have a registry where we can store the built container for use, so when we first download this repo, we will need to build the container.
from the root directory of this repo run `docker build -t mynodeapp .` This will use the Dockerfile in the current directory to build the image and will name it `mynodeapp`
This image name MUST correspond with the `image: mynodeapp` section in the docker-compose.yml file. This name is how docker-compose finds the image to use.
Once this completes, the image will be built, and we can use it.

## Docker Compose
if we run `docker-compose up` from this directory, docker will use the `docker-compose.yml` file to determine what needs to be done.
The way it is currently configured, we have 2 containers one is our app (mynodeapp) and the other is a mySQL database.

Each container is configured to mount some data from our computer into the container.
In the case of mynodeapp, it mounts everything in this directory, so that when we change either the backend app or the frontend, those changes will be pushed to the container.
The mySQL container mounts the `sql-startup-scripts` folder, this is used to initialize the sql database on container startup with our database schema and testing data.
If you want the sql database to persist between restarts of the container, uncomment the first mount on that container.

## Development Loop
In general, the development loop will be:
1. Modify the backend
2. restart the mynodeapp container (via docker)
3. see changes in backend
   
AND/OR
1. modify the frontend
2. rebuild the frontend (`npm run build` from neighbors-app directory)
3. see changes in UI

AND/OR
1. modify the sql database schema in sql-startup-scripts
2. restart the mysql container (via docker)
3. see changes in database

There should be a way to get the node backend to incorporate changes to the code without requiring a container restart, but it needs more research.

## NPM scripts
A couple helper functions have been added to the npm scripts in this directory and in the neighbors-app directory (the frontend angular app).
The root directory will build or install both the backend and frontend, the neighbors-app directory will only build/install the frontend code.
1. docker:build - will build the code from within the docker container
2. docker:install - will install production npm dependencies for the code within the docker container

We can also just do `npm install` or `npm run build` on our local commandline, since everything is mounted into the container it will get the updates.

## Running in school labs
This was done on linux, not sure if you can on Windows.

To use docker in the labs, you need to use [Vagrant](https://gitlab.cs.wwu.edu/cs-support/public/-/wikis/home/survival_guide/tools/virtual_machines/Vagrant) to configure the [docker VM](https://gitlab.cs.wwu.edu/cs-support/public/-/wikis/home/survival_guide/tools/Docker)

the Vagrantfile in this folder contains the necessary configuration to build a vagrant docker VM. However, there is more configuration necessary to get node and docker-compose installed.

Then run `vagrant up` This will create the VM with docker in it.

From there, use `vagrant ssh` to get a terminal connected to it.

This directory is mounted at `/home/vagrant/neighbors`, vagrant ssh starts you at `/home/vagrant`, so you'll need to cd to neighbors.

Then we need to install docker-compose, nvm, and nodejs, these commands are run in the vagrant VM:
1. `bash vagrant-init.sh` This will run all the commands needed to install docker-compose, nvm, and nodejs; as well as configuring the docker group permissions.
2. You will need to `exit` out of the vagrant ssh session and start a new one to get the path and tab completion all working.
3. run `docker-compose up -d` (if it errors about a missing container, you need to run `docker build -t mynodeapp .`)
    The -d flag tells it to run in the background, so you don't lose your terminal to the logs.
    you can either do this, or have this terminal scroll logs and `vagrant ssh` from another terminal to do CLI things.
4. At this point, `localhost:5000` should be working and serve the angular page. 
5. the VM seems really slow at building the frontend. not sure why.


# Template info below

### Node Express template project

This project is based on a GitLab [Project Template](https://docs.gitlab.com/ee/gitlab-basics/create-project.html).

Improvements can be proposed in the [original project](https://gitlab.com/gitlab-org/project-templates/express).

### CI/CD with Auto DevOps

This template is compatible with [Auto DevOps](https://docs.gitlab.com/ee/topics/autodevops/).

If Auto DevOps is not already enabled for this project, you can [turn it on](https://docs.gitlab.com/ee/topics/autodevops/#enabling-auto-devops) in the project settings.

### Developing with Gitpod

This template has a fully-automated dev setup for [Gitpod](https://docs.gitlab.com/ee/integration/gitpod.html).

If you open this project in Gitpod, you'll get all Node dependencies pre-installed and Express will open a web preview.
