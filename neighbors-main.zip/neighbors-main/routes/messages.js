var express = require('express');
var router = express.Router();
var mysql = require('mysql');
const util = require('util');
var jwtMiddleware = require('../lib/jwt-middleware')

var con = mysql.createConnection({
  host: "mysql",
  user: "root",
  password: "secret",
  database: "neighbors"
});
con.connect()

// node native promisify
const query = util.promisify(con.query).bind(con);

router.use(jwtMiddleware);


/* GET a conversation with a specific user */
router.get('/:userId', async function (req, res, next) {
    try {
        // default to `beginning of mySQL time` if since query param not passed.
        if(req.query.since == undefined) {
            req.query.since = '1000-01-01 00:00:00';
        }
        // req.userId is this user (from the auth token), req.params.userId is the person this user is getting the conversation for.
        let result = await query('select bin_to_uuid(msgId) as msgId, msgContent as content, msgTimestamp as "timestamp", msgRead as "read", bin_to_uuid(sender) as sender, bin_to_uuid(recipient) as recipient from Messages where ((uuid_to_bin(?) = sender AND uuid_to_bin(?) = recipient) OR (uuid_to_bin(?) = sender AND uuid_to_bin(?) = recipient)) AND msgTimestamp > ? order by msgTimestamp asc',[req.userId, req.params.userId, req.params.userId, req.userId, req.query.since]);
        res.send(result);
    } catch (error) {
        console.error(error);
        next(error)
    }
});

/* GET all the users I have chats with. */
router.get('/', async function(req, res, next) {
  try {
    console.log('getting all chats')
    console.log('getting chats');
    result = await query('Select distinct bin_to_uuid(con.userId) as userId from (select distinct fromMsg.sender as userId from Messages fromMsg where fromMsg.recipient = uuid_to_bin(?) UNION select distinct toMsg.recipient as userId from Messages toMsg where toMsg.sender = uuid_to_bin(?)) as con', [req.userId, req.userId]);
    console.log('got users');
    console.log(result)
    res.send(result);
  } catch (error) {
    console.error(error)
    next(error)
  }
});

/* post a message to a conversation */
router.post('/:userId', async function (req, res, next) {
    try {
        // req.userId is this user (from the auth token), req.params.userId is the person this user is getting the conversation for.
        let result = await query('insert into Messages (msgContent, msgRead, sender, recipient) values (?, false, uuid_to_bin(?), uuid_to_bin(?))',[req.body.content,  req.params.userId, req.userId]);
        console.log(result)
        res.send(result);
    } catch (error) {
        console.error(error);
        next(error)
    }
})

module.exports = router;
