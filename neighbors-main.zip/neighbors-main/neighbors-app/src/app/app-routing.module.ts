import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { InfoComponent  } from './info/info.component';
import { FormComponent } from './createPost/form.component';
import { NeedHelpComponent } from './forumPages/needHelp.component';
import { CanHelpComponent } from './forumPages/canHelp.component';
import { ServicesComponent } from './forumPages/services.component';
import { ReportComponent } from './report/reportuser.component';
import { ChatComponent } from './chat/chat.component';
import { LoginComponent } from './login/login.component';
import { ProfileComponent } from './profile/profile.component';

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'home', component: HomeComponent},
  { path: 'needHelp', component: NeedHelpComponent},
  { path: 'canHelp', component: CanHelpComponent},
  { path: 'services', component: ServicesComponent},
  { path: 'info', component: InfoComponent },
  { path: 'form', component: FormComponent },
  { path: 'chat', component: ChatComponent },
  { path: 'report', component: ReportComponent},
  { path: 'login', component: LoginComponent },
  { path: 'profile', component: ProfileComponent },
  { path: '*', redirectTo: '' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    onSameUrlNavigation: 'reload'
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }