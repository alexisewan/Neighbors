import { Injectable } from '@angular/core';
import { IPost } from '../interfaces/post';
import { Observable, of } from 'rxjs'
import { catchError, map, tap } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { IReport } from '../interfaces/report';
import { IMessage } from '../interfaces/message';

@Injectable({
  providedIn: 'root'
})
export class ChatService {
  private chatUrl = '/messages';
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache, no-store, must-revalidate, post-check=0, pre-check=0',
      'Pragma': 'no-cache',
      'Expires': '0'
    })
  };
  constructor(
    private http: HttpClient,
  ) { }

  /**
   * gets all uuids of this user's conversation partners.
   * @returns array of userIds from the API
   */
  getConversations(): Observable<{ userId: string }[]> {
    return this.http.get<{ userId: string }[]>(this.chatUrl).pipe(
      tap(_ => console.log('fetched convo users')),
      catchError(this.handleError<{ userId: string }[]>('getConversations', []))
    );
  }

  /**
   * gets all messages in a conversation.
   * @returns array of messages from the API, sorted by timestamp ascending
   */
  getConversation(userId: string, timeSince?: string): Observable<IMessage[]> {
    // if timeSince is passed in, use that to get messages in this conversation created since that time.
    const url = this.chatUrl + '/' + userId + (timeSince ? `?since=${encodeURIComponent(timeSince ?? "")}` : '')
    return this.http.get<IMessage[]>(url).pipe(
      tap(_ => { }),
      catchError(this.handleError<IMessage[]>('getConversation', []))
    );
  }

  /**
   * POSTs a message in a conversation to the server.
   * @returns array of messages from the API, sorted by timestamp ascending
   */
  sendMessage(userId: string, content: string): Observable<any> {
    // send the message content to the server.
    const url = this.chatUrl + '/' + userId
    return this.http.post<any>(url, { content: content }).pipe(
      tap(_ => console.log('sent message')),
      catchError(this.handleError<any>('sendMessage', []))
    );
  }

  /**
   * Handle Http operation that failed.
   * Let the app continue.
   * @param operation - name of the operation that failed
   * @param result - optional value to return as the observable result
   */
  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {

      // TODO: send the error to remote logging infrastructure
      console.error(error); // log to console instead

      // TODO: better job of transforming error for user consumption
      console.log(`${operation} failed: ${error.message}`);

      // Let the app keep running by returning an empty result.
      throw error
    };
  }
}
