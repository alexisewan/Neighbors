USE neighbors;

create table if not exists Languages(
    languageId int primary key AUTO_INCREMENT,
    languageName nvarchar(120) not null
);

create table if not exists ResourceCategories(
    categoryId int AUTO_INCREMENT primary key,
    resourceName varchar(32) not null
);


create table if not exists Locations(
    locationId int primary key AUTO_INCREMENT,
    streetAddress varchar(255) null,  
    city varchar(255) not null,
    country varchar(255) not null,
    zipCode int (11) not null
);

create table if not exists Users (
    userId 	binary(16) primary key default (uuid_to_bin(uuid())),
    loginName nvarchar(64) not null,
    email nvarchar(128) not null,
    passwordHash varchar(128) not null,
    salt  	VARCHAR(64) not null,
    lastName nvarchar(40) null,
    firstName nvarchar(40) null,
    profilePicture varbinary(10000) null,
    karma float(3,2) null,
    biography nvarchar(4000) null,
    locationId int null,
    languageId int null,
    CONSTRAINT fk_userLocation FOREIGN KEY (locationId) REFERENCES Locations (locationId),
    CONSTRAINT fk_userLanguage FOREIGN KEY (languageId) REFERENCES Languages (languageId)
);

create table if not exists Posts (
    postId binary(16) primary key default(uuid_to_bin(uuid())),
    title nvarchar(120) not null,
    photo varbinary(10000) null,
    postDesc nvarchar(4000) not null,
    postDuration DATETIME null,
    postCreateDate DATETIME not null DEFAULT CURRENT_TIMESTAMP,
    categoryId INT not null,
    userId binary(16) null,
    locationId int null,
    languageId int null,
    type varchar(15) not null,
    CONSTRAINT fk_post_category FOREIGN KEY (categoryId)
        REFERENCES ResourceCategories(categoryId),
    CONSTRAINT fk_post_user FOREIGN KEY (userId)
        REFERENCES Users(userId),
    CONSTRAINT fk_post_location FOREIGN KEY (locationId)
        REFERENCES Locations(locationId),
    CONSTRAINT fk_post_language FOREIGN KEY (languageId) REFERENCES Languages (languageId)
);

create table if not exists Services (
    serviceId binary(16) primary key default(uuid_to_bin(uuid())),
    serviceTitle nvarchar(100) not null,
    serviceDesc nvarchar(4000) not null,
    photo varbinary(10000) null,
    link varchar(4000) null,
    nextSteps nvarchar(4000) null,
    locationPublic boolean not null default false,
    categoryId int not null,
    userId binary(16) null,
    locationId int null,
    languageId int null,
    CONSTRAINT fk_service_category FOREIGN KEY (categoryId)
        REFERENCES ResourceCategories(categoryId),
    CONSTRAINT fk_service_user FOREIGN KEY (userId)
        REFERENCES Users(userId),
    CONSTRAINT fk_service_location FOREIGN KEY (locationId)
        REFERENCES Locations(locationId),
    CONSTRAINT fk_service_language FOREIGN KEY (languageId) REFERENCES Languages (languageId)
	/*
    languages from Languages not null*/
);

create table if not exists Messages(
    msgId binary(16) primary key default(uuid_to_bin(uuid())),
    msgContent nvarchar(4000) not null,
    msgTimestamp DATETIME not null DEFAULT CURRENT_TIMESTAMP,
    msgRead boolean not null DEFAULT false,
    sender binary(16) not null,
    recipient binary(16) not null,
    CONSTRAINT fk_sender_user FOREIGN KEY (sender)
        REFERENCES Users(userId),
    CONSTRAINT fk_recipient_user FOREIGN KEY (recipient)
        REFERENCES Users(userId)
);

create table if not exists Reports(
    reportId binary(16) primary key default(uuid_to_bin(uuid())),
    reportType nvarchar(16) not null,
    reportDesc nvarchar(4000) not null,
    reporterUserId binary(16) null,
    reportedUserId binary(16) null default null,
    postId binary(16) null default null,
    serviceId binary(16) null default null,
    CONSTRAINT fk_reported_user FOREIGN KEY (reportedUserId)
        REFERENCES Users(userId),
    CONSTRAINT fk_reporting_user FOREIGN KEY (reporterUserId)
        REFERENCES Users(userId),
    CONSTRAINT fk_reported_post FOREIGN KEY (postId)
        REFERENCES Posts(postId),
    CONSTRAINT fk_reported_service FOREIGN KEY (serviceId)
        REFERENCES Services(serviceId)
);

-- sprocs for adding a new user, and checking if a user's credentials match those already stored.
DROP PROCEDURE IF EXISTS uspAddUser;
DELIMITER //
CREATE PROCEDURE uspAddUser (
    IN pLogin nVARCHAR(64), 
    IN pPassword nVARCHAR(64), 
    IN pFirstName VARCHAR(40), 
    IN pLastName VARCHAR(40),
    IN pEmail VARCHAR(128)
    )
BEGIN
    DECLARE mySalt VARCHAR(36) DEFAULT UUID();
    DECLARE myHash varchar(128) default SHA2(concat(pPassword, mySalt), 512);
    INSERT INTO Users (loginName, passwordHash, salt, firstName, lastName, email, karma)
    VALUES (pLogin, myHash, mySalt, pFirstName, pLastName, pEmail, 0);
END //
DELIMITER ;

DROP PROCEDURE IF EXISTS uspLogin;
DELIMITER //
CREATE PROCEDURE uspLogin (
    IN pLogin nVARCHAR(64),
    IN pPassword nVARCHAR(64),
    OUT responseMessage nvarchar(64)
)
BEGIN
    DECLARE myId binary(16);
    declare myHash varchar(128);
    declare mySalt 	VARCHAR(64) ;
    IF ((Select count(*) FROM Users WHERE loginName = pLogin) > 0) THEN
        SET myId = (SELECT userID FROM Users WHERE loginName = pLogin AND passwordHash = SHA2(concat(pPassword, salt), 512));
       IF(myId IS NULL) THEN
           SET responseMessage='Incorrect password';
       ELSE 
           SET responseMessage='User successfully logged in';
        END IF;
    ELSE
       SET responseMessage='Invalid login';
    END IF;
END //
DELIMITER ;
-- populate initial db info.
insert into ResourceCategories (resourceName)
values ('Food'),('Housing'), ('Goods'), ('Transit'), ('Health'), ('Money'), ('Care'), ('Education'), ('Work'), ('Legal'), ('Restrooms'), ('Period Products');


-- Inserting some dummy population/testing values
call uspAddUser ('testUser', 'testUserPass', 'firstname', 'lastname', 'me@somewhere.com');
set @userId1 = (select userId from Users where loginName = 'testUser');
call uspAddUser ('testUser2', 'testUserPass', 'firstname2', 'lastname2', 'someone@somewhereelse.com');
set @userId2 = (select userId from Users where loginName = 'testUser2');
call uspLogin('test', 'test', @somevar);

insert into Messages (msgContent, sender, recipient) values ("hello there!", @userId1, @userId2);
insert into Messages (msgContent, sender, recipient) values ("why hello back to you!", @userId2, @userId1);
