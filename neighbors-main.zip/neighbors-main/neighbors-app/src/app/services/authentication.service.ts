 import { Injectable } from '@angular/core';
 import { HttpClient } from '@angular/common/http';
 import { Observable } from 'rxjs';
 import { catchError, shareReplay, tap } from 'rxjs/operators';
 import { IUserAuth } from '../interfaces/userAuth';
 import * as moment from 'moment'

 @Injectable({ providedIn: 'root' })
 export class AuthenticationService {

     constructor(private http: HttpClient) {
     }

     login(username:string, password:string ) {
       return this.http.post<IUserAuth>('/login', {username, password}).pipe(
         tap<IUserAuth>(result => this.setSession(result)),
         catchError(this.handleError<IUserAuth>(`login username=${username}`)),
         shareReplay(1)
       );
   }
   private setSession(authResult: IUserAuth) {
     const expiresAt = authResult.expiresIn

     localStorage.setItem('id_token', authResult.idToken);
     localStorage.setItem('user_id', authResult.userId);
     localStorage.setItem("expires_at", JSON.stringify(expiresAt.valueOf()) );
   }          

   logout() {
       localStorage.removeItem("id_token");
       localStorage.removeItem("expires_at");
       localStorage.removeItem('user_id');
   }

   public isLoggedIn() {
       return moment().isBefore(this.getExpiration());
   }

   isLoggedOut() {
       return !this.isLoggedIn();
   }

   getExpiration() {
       const expiration = localStorage.getItem("expires_at");
       if (expiration != null) {
         const expiresAt = JSON.parse(expiration);
         return moment(expiresAt);
       } else {
         return 0
       }
   }   

     /**
    * Handle Http operation that failed.
    * Let the app continue.
    * @param operation - name of the operation that failed
    * @param result - optional value to return as the observable result
    */
      private handleError<T>(operation = 'operation', result?: T) {
       return (error: any): Observable<T> => {
  
         // TODO: send the error to remote logging infrastructure
         console.error(error); // log to console instead
  
         // TODO: better job of transforming error for user consumption
         console.log(`${operation} failed: ${error.message}`);
  
         // Let the app keep running by returning an empty result.
         throw error
       };
     }
 }