var express = require('express');
var router = express.Router();
var mysql = require('mysql');
const { openStdin } = require('process');
const util = require('util');
const { v4: uuidv4 } = require('uuid');
var jwtMiddleware = require('../lib/jwt-middleware')

var con = mysql.createConnection({
  host: "mysql",
  user: "root",
  password: "secret",
  database: "neighbors"
});
con.connect()

// node native promisify
const query = util.promisify(con.query).bind(con);

router.use(jwtMiddleware);

/* GET posts listing. */
router.get('/', async function(req, res, next) {
  try {
    console.log('getting posts');
    let result = await query('Select BIN_TO_UUID(postID) as postId, title, photo, postDesc as description, postDuration as duration, postCreateDate as createDate, resourceName as category, type, bin_to_uuid(userId) as userId, locationId from Posts p join ResourceCategories r on r.categoryId = p.categoryId');
    console.log('got posts');
    // populate location information for the posts
    // TODO: make this part of a join in the first query
    for(let post of result) {
      if(post.locationId) {
        post.location = await query('select streetAddress, city, country, zipCode from Locations where locationId = ?', post.locationId)
        post.location = post.location[0]
        // TODO: remove once we have fiugred out where we are doing location generalizing
      }
      post.user = await query('select bin_to_uuid(userId) as userId, loginName as username, firstName, lastName, profilePicture, karma from Users where userId = uuid_to_bin(?)', post.userId)
      post.user = post.user[0]
      post.location = "5 miles";
    }
    res.send(result);
  } catch (error) {
    console.error(error)
    next(error)
  }
});

/* GET posts created by the calling user. */
router.get('/mine', async function(req, res, next) {
  try {
    console.log('getting posts');
    let result = await query('Select BIN_TO_UUID(postID) as postId, title, photo, postDesc as description, postDuration as duration, postCreateDate as createDate, resourceName as category, type, bin_to_uuid(userId) as userId, locationId from Posts p join ResourceCategories r on r.categoryId = p.categoryId where p.userId = uuid_to_bin(?)', req.userId);
    console.log('got posts');
    // populate location information for the posts
    // TODO: make this part of a join in the first query
    for(let post of result) {
      if(post.locationId) {
        post.location = await query('select streetAddress, city, country, zipCode from Locations where locationId = ?', post.locationId)
        post.location = post.location[0]
        // TODO: remove once we have fiugred out where we are doing location generalizing
      }
      post.user = await query('select bin_to_uuid(userId) as userId, loginName as username, firstName, lastName, profilePicture, karma from Users where userId = uuid_to_bin(?)', post.userId)
      post.user = post.user[0]
      post.location = "5 miles";
    }
    res.send(result);
  } catch (error) {
    console.error(error)
    next(error)
  }
});


/* GET post */
router.get('/:postId', async function(req, res, next) {
  try {
    let post = await getPost(req.params.postId)
    res.send(post);
  } catch (error) {
    console.error(error)
    next(error)
  }
});
/* POST post. */
router.post('/', async function(req, res, next) {
  try {
    console.log('inserting a post');
    console.log(req.body.location)
    // minimal check that location and streetAddress are defined, before inserting the location.
    if (req.body.location != undefined && req.body.location.streetAddress != undefined) {
      // insert the location if it does not exist already.
      let locationResults = await query('select locationId from `Locations` where streetAddress = ? and city = ? and country = ? and zipCode = ?', [req.body.location.streetAddress, req.body.location.city, req.body.location.country, req.body.location.zipCode]);
      console.log(locationResults)
      if (locationResults.length == 0) {
        // we need to insert the location.
        locationResults = await query('INSERT INTO Locations SET ?', req.body.location);
        console.log(locationResults.insertId);
        req.body.locationId = locationResults.insertId;
      } else {
        console.log(locationResults[0])
        req.body.locationId = locationResults[0].locationId
      }
    }
    let results = await query('select categoryId from ResourceCategories where resourceName = ?', req.body.category)
    if (results.length == 0) {
      throw `Could not find category ${req.body.category}`;
    } else {
      let postUuid = uuidv4();
      postResult = await query ('insert into `Posts` (postId, title, postDesc, postDuration, categoryId, locationId, type, userId) values (uuid_to_bin(?), ?, ?, ?, ?, ?, ?, uuid_to_bin(?))', [postUuid, req.body.title, req.body.description, req.body.duration, results[0].categoryId, req.body.locationId, req.body.type, req.userId]);
      console.log('inserted a post');
      let post = await getPost(postUuid);
      res.send(post);
    }
  } catch (error) {
    console.error(error)
    next(error)
  }
});


/* report a post */
router.put('/:postId/report', async function(req, res, next) {
  try {
    console.log('reporting post: ', req.params.postId);
    let reportUuid = uuidv4();
    let reportResults = await query('insert into `Reports` (reportId, reportType, reportDesc, postId, reporterUserId) values (uuid_to_bin(?), ?, ?, uuid_to_bin(?), uuid_to_bin(?))', [reportUuid, req.body.reportType, req.body.reportDescription, req.params.postId, req.userId]);
    let report = await query('select bin_to_uuid(reportId) reportId, reportType, reportDesc as reportDescription, bin_to_uuid(reporterUserId) as reporterUserId, bin_to_uuid(postId) as postId from Reports where reportId = uuid_to_bin(?)', reportUuid)
    res.send(report[0])
  } catch(error) {
    console.error(error)
    next(error)
  }
});

/* UPDATE post. */
router.put('/:postId', async function(req, res, next) {
  try {
      console.log('updating post');
      // parse through request and see what changed.
      let sqlUpdate = '';
      if(req.body.title) {
        sqlUpdate += `title = '${connection.escape(req.body.title)}'`
      }
      if (req.body.description) {
        sqlUpdate += `postDesc = '${connection.escape(req.body.description)}'`
      }
      if (req.body.duration) {
        sqlUpdate += `postDuration = '${connection.escape(req.body.duration)}'`
      }
      if (req.body.category) {
        // get new category ID
        categoryResults = await query('select categoryId from ResourceCategories where categoryName = ?', req.body.category)
        if (categoryResults.length == 0) {
          throw `category ${req.body.category} does not exist`;
        } else {
          sqlUpdate += `category = ${categoryResults[0].categoryId}`
        }
      }
      if(sqlUpdate == '') {
        throw 'Nothing to update'
      }
      sqlUpdate = 'update `Posts` SET ' + sqlUpdate + ` where postId = uuid_to_bin(${connection.escape(req.params.postId)})`
      let result = await query(sqlUpdate);
      console.log(`updated post: ${req.params.postId}`);
      let post = await getPost(req.params.postId);
      res.send(post);
    } catch (error) {
      console.error(error)
      next(error)
    }
});

/* DELETE post. */
router.delete('/:postId', async function(req, res, next) {
  try {
    console.log('deleting post');
    let results = await query('delete from `Posts` where postId = uuid_to_bin(?)', req.params.postId);
    console.log('deleted a post');
    if (results.affectedRows < 2) {
      res.send('success');
    } else {
      throw `error deleting ${postId}`
    }
  } catch (error) {
    console.error(error)
    next(error)
  }
});

// Helper / internal functions
async function getPost(postId) {
  let postResult = await query('Select BIN_TO_UUID(postId) as postId, title, photo, postDesc as description, postDuration as duration, resourceName as category, type, bin_to_uuid(userId) as userId, locationId from `Posts` p join `ResourceCategories` r on r.categoryId = p.categoryId where p.postId = uuid_to_bin(?)', postId)
  console.log('got post');
  if (postResult.length == 0) {
    throw `No post matching: ${postId}`
  } else {
    postResult = postResult[0]
    // populate location information for the post
    if (postResult.locationId) {
      postResult.location = await query('select streetAddress, city, country, zipCode from `Locations` where locationId = ?', postResult.locationId)
      if(postResult.location.length == 0) {
        throw `No location found for post: ${postId}`;
      }
      postResult.location = postResult.location[0]
      delete postResult.locationId
    }
    postResult.user = await query('select bin_to_uuid(userId) as userId, loginName as username, firstName, lastName, profilePicture, karma from Users where userId = uuid_to_bin(?)', postResult.userId)
    postResult.user = postResult.user[0]
    // TODO: remove once we have fiugred out where we are doing location generalizing
    postResult.location = "5 miles";
    return postResult;
  }
}

module.exports = router;
