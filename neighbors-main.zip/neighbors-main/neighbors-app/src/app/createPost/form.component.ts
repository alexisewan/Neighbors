import { Component } from '@angular/core';
import { IPost } from '../interfaces/post';
import { IUser } from '../interfaces/user';
import { PostService } from '../services/post.service';
import { ServiceService } from '../services/service.service';

@Component({
  selector: 'app-root',
  templateUrl: './form.component.html'
})
export class FormComponent {
  title = 'neighbors-app';
  formType = 'Post';

  post: IPost = {postId: '', photo: '', type: '', category: '', title: '', description: '', duration: 'dd/mm/yyyy', location: ''};

  constructor(
    private postService: PostService,
    private serviceService: ServiceService
  ) {}

  onSubmit(): void {
    console.log('Post has been submitted');
    console.log(this.post);
    if(this.ValidatePost() == false){
      console.log("Invalid post. Aborting submission.");
      return;
    }
    this.AddPost();
    this.post = {postId: '', photo: '', type: '', category: '', title: '', description: '', duration: 'dd/mm/yyyy', location: ''};
  }

  AddPost() {
    let serviceToUse: PostService | ServiceService
    if(this.post.type == 'Donation' || this.post.type == 'Request') {
      serviceToUse = this.postService;
    } else {
      serviceToUse = this.serviceService;
    }
    serviceToUse.add(this.post).subscribe((post) => {console.log (post)}, (error) => {console.error(error)});
  }

  ValidatePost(){
    // if(!this.post.postId){
    //   alert("Error creating post. Please try again.");
    // } else 
    if(this.post.type == ''){
      alert("You must select a post type. Please try again.");
    } else if(this.post.category == ''){
      alert("You must select a category. Please try again.");
    } else if (this.post.title == ''){
      alert("You must include a title. Please try again.");
    } else if(this.post.description == ''){
      alert("You must include a description. Please try again.");
    } else if(this.post.location == ''){
      alert("You must include a location. Your location will not be shared with any users. Please try again.");
    } else {
      return true;
    }
    return false;
  }
}
