var express = require('express');
var router = express.Router();
var mysql = require('mysql');
const util = require('util');
const jwtMiddleware = require('../lib/jwt-middleware');

var con = mysql.createConnection({
  host: "mysql",
  user: "root",
  password: "secret",
  database: "neighbors"
});
con.connect()

// node native promisify
const query = util.promisify(con.query).bind(con);

router.use(jwtMiddleware);

/* GET users listing. */
router.get('/', async function(req, res, next) {
  try {
    console.log('getting users');
    result = await query('Select BIN_TO_UUID(userid) as userId, loginName as username, lastName, firstName, karma from `Users`');
    console.log('got users');
    console.log(result)
    res.send(result);
  } catch (error) {
    console.error(error)
    next(error)
  }
});

/* GET this user listing. */
router.get('/self', async function(req, res, next) {
  try {
    console.log('getting user' + req.userId);
    let result = await query('Select BIN_TO_UUID(userid) as userId, loginName as username, lastName, firstName, karma from `Users` where userId = uuid_to_bin(?)', req.userId);
    console.log('got user');
    console.log(result)
    if (result.length != 1) {
      throw 'incorrect number of users returned'
    }
    res.send(result[0]);
  } catch (error) {
    console.error(error);
    next(error)
  }
});

/* GET a specific user */
router.get('/:userId', async function (req, res, next) {
  try {
    console.log('getting user' + req.params.userId);
    let result = await query('Select BIN_TO_UUID(userid) as userId, loginName as username, lastName, firstName, karma from `Users` where userId = uuid_to_bin(?)', req.params.userId);
    console.log('got user');
    console.log(result)
    if (result.length != 1) {
      throw 'incorrect number of users returned'
    }
    res.send(result[0]);
  } catch (error) {
    console.error(error);
    next(error)
  }
});

module.exports = router;
