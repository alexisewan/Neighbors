import {IUser} from './user'

export interface IPost {
    // This portion could be in it's own interface I'm not sure yet
    // link to user profile
    // username
    // user rating
    postId: string,
    photo: string,
    type: string,
    category: string,
    title: string,
    description: string,
    duration: string,
    // currently backend sets this to 5 miles for all responses
    location: string,
    // make nullable so we can send a post without user data back (since user info already added via authentication token)
    user?: IUser
}