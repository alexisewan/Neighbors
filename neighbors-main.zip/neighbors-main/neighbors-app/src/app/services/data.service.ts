import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class DataService{
    private data:any = undefined;

    setData(data:any){
        this.data = data;
    }

    getData():any{
        return this.data;
    }

    getType():any{
        console.log("Data is of type: " + typeof(this.data));
        return typeof(this.data);
    }
}