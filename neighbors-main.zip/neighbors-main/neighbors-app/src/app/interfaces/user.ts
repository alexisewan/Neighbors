export interface IUser {
    userId: string,
    username: string,
    firstName: string,
    lastName: string,
    profilePicture: Blob,
    karma: number,
    userLocation: string,
    userLanguage: string
}