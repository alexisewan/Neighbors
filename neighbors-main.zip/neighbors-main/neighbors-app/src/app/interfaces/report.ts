// minimal information for a report
export interface IReport {
    reportId: string,
    reportType: string,
    reportDescription: string,
    // this is nullable since when first created in the frontend, it will not be populated
    reporterUserId?: string,
    // one of these will be defined, depending on whether this is a report for a post, service, or user.
    postId?: string,
    serviceId?: string,
    reportedUserId?: string
}