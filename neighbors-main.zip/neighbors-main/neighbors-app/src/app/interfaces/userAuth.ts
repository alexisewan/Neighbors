export interface IUserAuth {
    idToken: string,
    userId: string,
    expiresIn: string
}