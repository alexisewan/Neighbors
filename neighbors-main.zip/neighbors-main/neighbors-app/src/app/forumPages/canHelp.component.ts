// TODO: Add function to pull from the database and add the infromation to the list of posts when the page loads

import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { IPost } from '../interfaces/post';
import { PostService } from '../services/post.service';
import { DataService } from '../services/data.service';


@Component({
  selector: 'app-root',
  templateUrl: './canHelp.component.html'
})
export class CanHelpComponent {
  title = 'neighbors-app';
  filter = '';
  posts: IPost[] = [];

  constructor(private postService: PostService, private sharingService: DataService, private router: Router) {}

  ngOnInit() {
    this.getPosts()
  }

  getPosts() {
    this.postService.getAll()
    .subscribe((posts) => {
      console.log(posts)
      this.posts = posts;
    });
  }

  SetFilter(clickedFilter: string) {
    if(this.filter == clickedFilter)
      this.filter = '';
    else
      this.filter= clickedFilter;
  }

  viewProfile(post: IPost) {
    this.sharingService.setData(post.user);
    this.router.navigate(['/profile']);
  }

  reportUser(post: IPost) {
    this.sharingService.setData(post.user?.userId);
    this.router.navigate(['/report']);
  }

  // UserButton(username?: string){
  //   if(confirm("View " + username + "'s Profile?") == true){
  //     //reroute to user's profile
  //     this.router.navigate(['/profile']);
  //   }
  // }
}

 
